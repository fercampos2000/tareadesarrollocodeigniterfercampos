<link href="<?= base_url('public/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet">
